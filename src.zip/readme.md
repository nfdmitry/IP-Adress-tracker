# Команды:

## Запуск сервера для разработки
    - npm run start
## Сборка проекта без оптимизации
    - npm run build-dev
## Сборка проекта с оптимизацией
    - npm run build-prod
## Очистка папки dist
    - npm run clear